"""Local integration and mocked provider contracts; never calls paid/live APIs."""
import unittest,tempfile,threading,json,os,sqlite3,time
from pathlib import Path
from unittest.mock import patch
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from urllib.parse import urlsplit
import server,storage,ai_service,free_data,preflight

class Launch(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.tmp=tempfile.TemporaryDirectory();server.DB=Path(cls.tmp.name)/'launch.db';server.db().close()
  cls.s=server.BoundedServer(('127.0.0.1',0),server.H);threading.Thread(target=cls.s.serve_forever,daemon=True).start();cls.base='http://127.0.0.1:'+str(cls.s.server_port)
  cls.env=patch.dict(os.environ,{'ADMIN_EMAILS':'owner@example.test'});cls.env.start()
  cls.owner=cls.account('owner@example.test');cls.member=cls.account('member@example.test')
 @classmethod
 def tearDownClass(cls):cls.s.shutdown();cls.s.server_close();cls.env.stop();storage.cleanup();cls.tmp.cleanup()
 @classmethod
 def call(cls,path,body=None,cookie='',origin=None):
  h={'Content-Type':'application/json','Cookie':cookie}
  if origin:h['Origin']=origin
  req=Request(cls.base+path,data=None if body is None else json.dumps(body).encode(),headers=h)
  try:r=urlopen(req)
  except HTTPError as e:r=e
  raw=r.read();return r.status,json.loads(raw) if 'json' in r.headers.get('Content-Type','') else raw,r.headers
 @classmethod
 def account(cls,email):
  status,x,_=cls.call('/api/auth/register',{'email':email,'password':'test-password-long'});assert status==200
  cls.call('/api/auth/verify?'+urlsplit(x['dev_verification_url']).query)
  status,x,h=cls.call('/api/auth/login',{'email':email,'password':'test-password-long'});assert status==200
  cookie=h['Set-Cookie'];assert 'HttpOnly' in cookie and 'SameSite=Lax' in cookie
  return cookie.split(';')[0]
 def test_cookie_and_csrf(self):
  self.assertTrue(self.call('/api/auth/me',cookie=self.member)[1]['authenticated'])
  self.assertEqual(self.call('/api/saved/add',{'kind':'watchlist','symbol':'BTC'},self.member,'https://evil.test')[0],403)
 def test_saved_isolation_validation(self):
  self.assertEqual(self.call('/api/saved/add',{'kind':'portfolio','symbol':'BTC','value':'NaN'},self.member)[0],400)
  self.assertEqual(self.call('/api/saved/add',{'kind':'watchlist','symbol':'BTC'},self.member)[0],200)
  rows=self.call('/api/saved?kind=watchlist',cookie=self.member)[1]['data'];self.assertTrue(rows)
  self.assertEqual(self.call('/api/saved/remove',{'id':rows[0]['id']},self.owner)[0],404)
  self.assertEqual(self.call('/api/saved/remove',{'id':rows[0]['id']},self.member)[0],200)
 def test_moderation_and_reactions(self):
  _,p,_=self.call('/api/feed/post',{'body':'Community fixture','label':'Prediction'},self.member);pid=p['id']
  for _ in range(2):self.assertEqual(self.call('/api/feed/reaction',{'post_id':pid,'active':True},self.member)[0],200)
  row=next(x for x in self.call('/api/feed',cookie=self.member)[1]['data'] if x['id']==pid);self.assertEqual(row['reactions'],1);self.assertEqual(row['label'],'Prediction')
  self.assertEqual(self.call('/api/feed/report',{'kind':'post','target_id':pid,'reason':'Please review source'},self.member)[0],200)
  data={'action':'hide','kind':'post','target_id':pid}
  self.assertEqual(self.call('/api/admin/moderate',data,self.member)[0],403)
  self.assertEqual(self.call('/api/admin/moderate',data,self.owner)[0],200)
  self.assertNotIn(pid,[x['id'] for x in self.call('/api/feed')[1]['data']])
  self.assertEqual(self.call('/api/feed/comment',{'post_id':pid,'body':'No hidden comment'},self.member)[0],404)
 def test_admin_access(self):
  self.assertEqual(self.call('/api/admin',cookie=self.member)[0],403)
  self.assertEqual(self.call('/api/admin',cookie=self.owner)[0],200)
 def test_owner_export_authorization(self):
  self.assertEqual(self.call('/api/admin/export?kind=accounts',cookie=self.member)[0],403)
  status,body,h=self.call('/api/admin/export?kind=accounts',cookie=self.owner)
  self.assertEqual(status,200);self.assertIn(b'owner@example.test',body);self.assertNotIn(b'password_hash',body);self.assertIn('attachment',h['Content-Disposition'])
  self.assertEqual(self.call('/api/admin/operations',cookie=self.member)[0],403)
 def test_ai_consent(self):
  self.assertEqual(self.call('/api/ai',{'question':'BTC price?'},self.member)[0],400)
  with patch('ai_service.enabled',return_value=[]):self.assertEqual(self.call('/api/ai',{'question':'BTC price?','consent':True},self.member)[1]['status'],'UNAVAILABLE')
 def test_password_reset_one_time(self):
  cookie=self.account('reset@example.test')
  _,x,_=self.call('/api/auth/reset-request',{'email':'reset@example.test'});token=urlsplit(x['dev_verification_url']).fragment.split('=')[1]
  body={'token':token,'password':'new-test-password'}
  self.assertEqual(self.call('/api/auth/reset',body)[0],200)
  self.assertEqual(self.call('/api/auth/reset',body)[0],400)
  self.assertFalse(self.call('/api/auth/me',cookie=cookie)[1]['authenticated'])
 def test_threshold_deduplication(self):
  self.call('/api/saved/add',{'kind':'alerts','symbol':'BTC','value':10},self.member)
  fixture={'status':'SNAPSHOT','data':[{'symbol':'BTC','price':11,'source':'fixture','updated':server.iso(server.now())}]}
  with patch.dict(free_data.CACHE,{'crypto':fixture},clear=True):
   first=self.call('/api/notifications',cookie=self.member)[1]['data'];second=self.call('/api/notifications',cookie=self.member)[1]['data']
   self.assertEqual(len(first),1);self.assertEqual(len(second),1)
 def test_preflight_blocks_missing_accounts(self):
  with patch.dict(os.environ,{},clear=True):self.assertGreater(len(preflight.check()),5)
 def test_production_refuses_local_database(self):
  with patch.dict(os.environ,{'VANTIX_ENV':'production'},clear=True):
   with self.assertRaises(sqlite3.OperationalError):storage.connect(server.DB,'')

class Providers(unittest.TestCase):
 def setUp(self):
  self.c=sqlite3.connect(':memory:');self.c.row_factory=sqlite3.Row;self.c.executescript(Path(__file__).with_name('launch_schema.sql').read_text())
  self.cache={'crypto':{'status':'SNAPSHOT','retrieved_at':server.iso(server.now()),'data':[{'symbol':'BTC','price':10,'source_url':'https://example.test/source'}]}}
 def tearDown(self):self.c.close()
 def test_nvidia_not_production(self):
  with patch.dict(os.environ,{'VANTIX_ENV':'production','NVIDIA_API_KEY':'test','NVIDIA_DEVELOPMENT_ENABLED':'1'},clear=True):self.assertEqual(ai_service.enabled(),[])
 def test_fallback_and_bound_sources(self):
  env={'OPENROUTER_API_KEY':'test','OPENROUTER_FREE_ONLY':'1','GROQ_API_KEY':'test','GROQ_FREE_TIER_CONFIRMED':'1'}
  good={'choices':[{'message':{'content':json.dumps({'answer':'BTC source [S1]','source_ids':['S1'],'limitations':'No causal evidence'})}}]}
  with patch.dict(os.environ,env,clear=True),patch('ai_service.post',side_effect=[OSError(),good]) as req:
   result=ai_service.answer('BTC',1,self.c,self.cache);self.assertEqual(result['provider'],'groq');self.assertEqual(req.call_count,2)
   self.assertNotIn('password',json.dumps(req.call_args.args[1]));self.assertEqual(result['sources'][0]['source_url'],'https://example.test/source')
 def test_unknown_citation_rejected(self):
  raw={'choices':[{'message':{'content':'{"answer":"invented","source_ids":["S99"]}'}}]}
  with patch.dict(os.environ,{'OPENROUTER_API_KEY':'test','OPENROUTER_FREE_ONLY':'1'},clear=True),patch('ai_service.post',return_value=raw):self.assertEqual(ai_service.answer('BTC',1,self.c,self.cache)['status'],'UNAVAILABLE')
 def test_stale_evidence_excluded(self):
  self.cache['crypto']['retrieved_at']='2000-01-01T00:00:00+00:00';self.assertEqual(ai_service.evidence(self.cache,'BTC'),[])
 def test_atomic_quota(self):
  self.assertTrue(ai_service.reserve(self.c,'fixture',1));self.assertFalse(ai_service.reserve(self.c,'fixture',1))
 def test_remote_protocol(self):
  payloads=[]
  class Response:
   def __enter__(self):return self
   def __exit__(self,*a):pass
   def read(self,*a):return json.dumps({'baton':'b','results':[{'type':'ok','response':{'result':{'cols':[{'name':'n'}],'rows':[[{'type':'integer','value':'7'}]],'last_insert_rowid':'2'}}}]}).encode()
  def fake(req,**kw):payloads.append(json.loads(req.data));return Response()
  with patch.dict(os.environ,{'LIBSQL_URL':'libsql://fixture.turso.io','LIBSQL_AUTH_TOKEN':'secret'}),patch('storage.urlopen',fake):
   c=storage.Remote();self.assertEqual(c.execute('SELECT 7 n').fetchone()['n'],7);c.execute('INSERT INTO t VALUES(?)',(2,));c.commit();c.close()
  self.assertEqual(payloads[1]['requests'][0]['stmt']['sql'],'BEGIN IMMEDIATE');self.assertEqual(payloads[2]['requests'][0]['stmt']['args'][0],{'type':'integer','value':'2'});self.assertNotIn('secret',json.dumps(payloads))
 def test_one_refresh_does_not_block_other_sources(self):
  free_data.CACHE.clear();started=threading.Event();release=threading.Event()
  def slow():started.set();release.wait(2);return []
  t=threading.Thread(target=lambda:free_data.cached('slow','fixture','https://example.test',slow));t.start();started.wait(1)
  try:
   self.assertEqual(free_data.cached('slow','fixture','https://example.test',slow)['status'],'REFRESHING')
   self.assertEqual(free_data.cached('other','fixture','https://example.test',lambda:[])['status'],'EMPTY')
  finally:release.set();t.join()
if __name__=='__main__':unittest.main()
